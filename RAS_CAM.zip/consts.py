import os 

FOLDER_NAME = "RAS_CAM"




